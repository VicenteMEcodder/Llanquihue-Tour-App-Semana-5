package data;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import model.Guia;
import model.Operador;
import model.Proveedor;
import model.Tour;

public class DataManager {
    private List<Guia> guias;
    private List<Proveedor> proveedores;
    private List<Operador> operadores;
    private List<Tour> tours;

    public DataManager() {
        this.guias = new ArrayList<>();
        this.proveedores = new ArrayList<>();
        this.operadores = new ArrayList<>();
        this.tours = new ArrayList<>();
    }

    public void cargarTodosLosDatos() {
        System.out.println("=== CARGANDO DATOS DE LA AGENCIA ===\n");
        
        this.guias = DataLoader.cargarGuias("guias.txt");
        this.proveedores = DataLoader.cargarProveedores("proveedores.txt");
        this.operadores = DataLoader.cargarOperadores("operadores.txt");
        this.tours = DataLoader.cargarTours("tours.txt", this.guias, this.proveedores);
        
        System.out.println("\n=== CARGA COMPLETADA ===\n");
    }

    // Getters
    public List<Guia> getGuias() { return guias; }
    public List<Proveedor> getProveedores() { return proveedores; }
    public List<Operador> getOperadores() { return operadores; }
    public List<Tour> getTours() { return tours; }

    public List<Guia> buscarGuiasPorEspecialidad(String especialidad) {
        return guias.stream()
                .filter(g -> g.getEspecialidad().toLowerCase().contains(especialidad.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Guia> buscarGuiasCertificadas() {
        return guias.stream()
                .filter(Guia::isCertificado)
                .collect(Collectors.toList());
    }

    public List<Proveedor> buscarProveedoresPorRubro(String rubro) {
        return proveedores.stream()
                .filter(p -> p.getRubro().toLowerCase().contains(rubro.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Proveedor> buscarProveedoresActivos() {
        return proveedores.stream()
                .filter(Proveedor::isActivo)
                .collect(Collectors.toList());
    }

    public List<Tour> buscarToursPorPrecio(double precioMaximo) {
        return tours.stream()
                .filter(t -> t.getPrecio() <= precioMaximo)
                .collect(Collectors.toList());
    }

    //Mostrar estadistica
    public void mostrarEstadisticas() {
        System.out.println("\n=== ESTADÍSTICAS DE LA AGENCIA ===\n");
        System.out.println("Total de Guías: " + guias.size());
        System.out.println("Total de Proveedores: " + proveedores.size());
        System.out.println("Total de Operadores: " + operadores.size());
        System.out.println("Total de Tours: " + tours.size());
        
        if (!guias.isEmpty()) {
            long certificados = guias.stream().filter(Guia::isCertificado).count();
            System.out.println("\nGuías certificados: " + certificados + " (" + 
                             (certificados * 100 / guias.size()) + "%)");
        }
        
        if (!proveedores.isEmpty()) {
            long activos = proveedores.stream().filter(Proveedor::isActivo).count();
            System.out.println("Proveedores activos: " + activos + " (" + 
                             (activos * 100 / proveedores.size()) + "%)");
        }
    }

    //Mostrar todos los datos
    public void mostrarTodosLosDatos() {
        System.out.println("\n=== LISTADO COMPLETO DE DATOS ===\n");
        
        System.out.println("--- GUÍAS (" + guias.size() + ") ---");
        guias.forEach(System.out::println);
        
        System.out.println("\n--- PROVEEDORES (" + proveedores.size() + ") ---");
        proveedores.forEach(System.out::println);
        
        System.out.println("\n--- OPERADORES (" + operadores.size() + ") ---");
        operadores.forEach(System.out::println);
        
        System.out.println("\n--- TOURS (" + tours.size() + ") ---");
        tours.forEach(System.out::println);
    }
}