package service;

import java.util.List;
import java.util.Scanner;

import data.DataManager;
import model.Guia;
import model.Proveedor;
import model.Tour;

public class BusquedaService {
    private final DataManager dataManager;
    private final Scanner scanner;

    public BusquedaService(DataManager dataManager) {
        this.dataManager = dataManager;
        this.scanner = new Scanner(System.in);
    }

    public void buscarGuiasPorEspecialidad() {
        System.out.println("\n=== BÚSQUEDA DE GUÍAS POR ESPECIALIDAD ===\n");
        System.out.print("Ingrese la especialidad a buscar: ");
        String especialidad = scanner.nextLine();
        
        List<Guia> resultados = dataManager.buscarGuiasPorEspecialidad(especialidad);
        
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron guías con esa especialidad.");
        } else {
            System.out.println("\nRESULTADOS (" + resultados.size() + " guías):");
            resultados.forEach(System.out::println);
        }
    }

    public void buscarGuiasCertificadas() {
        System.out.println("\n=== GUÍAS CERTIFICADAS ===\n");
        
        List<Guia> certificados = dataManager.buscarGuiasCertificadas();
        
        if (certificados.isEmpty()) {
            System.out.println("No hay guías certificadas registrados.");
        } else {
            System.out.println("GUÍAS CERTIFICADOS (" + certificados.size() + "):");
            certificados.forEach(System.out::println);
        }
    }

    public void buscarProveedoresPorRubro() {
        System.out.println("\n=== BÚSQUEDA DE PROVEEDORES POR RUBRO ===\n");
        System.out.print("Ingrese el rubro a buscar: ");
        String rubro = scanner.nextLine();
        
        List<Proveedor> resultados = dataManager.buscarProveedoresPorRubro(rubro);
        
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron proveedores con ese rubro.");
        } else {
            System.out.println("\nRESULTADOS (" + resultados.size() + " proveedores):");
            resultados.forEach(System.out::println);
        }
    }

    public void buscarToursPorPrecio() {
        System.out.println("\n=== BÚSQUEDA DE TOURS POR PRECIO ===\n");
        System.out.print("Ingrese el precio máximo: ");
        double precioMax = Double.parseDouble(scanner.nextLine());
        
        List<Tour> resultados = dataManager.buscarToursPorPrecio(precioMax);
        
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron tours con precio menor o igual a $" + precioMax);
        } else {
            System.out.println("\n RESULTADOS (" + resultados.size() + " tours):");
            resultados.forEach(System.out::println);
        }
    }

    // CORREGIDO: Usando Rule Switch (Java 14+)
    public void mostrarMenuBusqueda() {
        System.out.println("\n=== MENÚ DE BÚSQUEDA ===");
        System.out.println("1. Buscar Guías por Especialidad");
        System.out.println("2. Ver Guías Certificadas");
        System.out.println("3. Buscar Proveedores por Rubro");
        System.out.println("4. Buscar Tours por Precio Máximo");
        System.out.println("5. Volver al menú principal");
        System.out.print("Seleccione una opción: ");
        
        int opcion = Integer.parseInt(scanner.nextLine());
        
        switch (opcion) {
            case 1 -> buscarGuiasPorEspecialidad();
            case 2 -> buscarGuiasCertificadas();
            case 3 -> buscarProveedoresPorRubro();
            case 4 -> buscarToursPorPrecio();
            case 5 -> System.out.println("Volviendo al menú principal...");
            default -> System.out.println("Opción no válida");
        }
    }
}